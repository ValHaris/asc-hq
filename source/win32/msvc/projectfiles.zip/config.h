/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 0

/* Define if you have the itoa function.  */
/* #undef HAVE_ITOA */
#define HAVE_ITOA 1

/* Define if you have the select function.  */
#define HAVE_SELECT 1

/* Define if you have the stricmp function.  */
#define HAVE_STRICMP 1

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 0
//#undef HAVE_DIRENT_H

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <strings.h> header file.  */
#define HAVE_STRINGS_H 1

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/dirent.h> header file.  */
/* #undef HAVE_SYS_DIRENT_H */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the SDL library (-lSDL).  */
#define HAVE_LIBSDL 1

/* Define if you have the bz2 library (-lbz2).  */
#define HAVE_LIBBZ2 1

/* Define if you have the pthread library (-lpthread).  */
#define HAVE_LIBPTHREAD 1

/* Name of package */
#define PACKAGE "asc"

/* Version number of package */
#define VERSION "0.1"


